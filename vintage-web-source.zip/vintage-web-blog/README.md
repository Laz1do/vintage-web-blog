# Vintage Web Blog

Original Vintage Web Hugo theme and sample content by [madebydia](https://github.com/madebydia/vintage-web-hugo-theme), used under the included MIT license.

## GitHub Pages

Create the public repository `Laz1do/vintage-web-blog` and upload this project's source, including `.github/workflows/pages.yml` and the `themes` folder.

In repository Settings → Pages, select **GitHub Actions** as the source. Push to `main` or manually run **Publish Vintage Web**.

The expected URL after successful deployment is https://laz1do.github.io/vintage-web-blog/ .

## Editing

Edit `hugo.toml` for site settings and `content/` for posts. Theme example content is retained. This is a static site; its sample guestbook does not store messages on a server.

## Local build

Use Hugo 0.166.0 and run `hugo --minify`. The generated static website is in `public/`.
